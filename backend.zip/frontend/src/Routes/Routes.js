// import modular Routes
import chartRoutes from './Chart';

export default [ ...chartRoutes ];

import configureStore from './config';

export default configureStore();

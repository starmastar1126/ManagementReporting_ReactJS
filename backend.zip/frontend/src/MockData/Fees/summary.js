const data = [
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 1,
    "Date": "2018-07-01",
    "ActualFees": 329639.08,
    "ForecastFees": 318200
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 2,
    "Date": "2018-08-01",
    "ActualFees": 339989.43,
    "ForecastFees": 314860
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 3,
    "Date": "2018-09-01",
    "ActualFees": 344828.03,
    "ForecastFees": 302000
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 4,
    "Date": "2018-10-01",
    "ActualFees": 374203.93,
    "ForecastFees": 366420
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 5,
    "Date": "2018-11-01",
    "ActualFees": 393838.69,
    "ForecastFees": 365550
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 6,
    "Date": "2018-12-01",
    "ActualFees": 289575,
    "ForecastFees": 290075
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 7,
    "Date": "2019-01-01",
    "ActualFees": 0,
    "ForecastFees": 0
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 8,
    "Date": "2019-02-01",
    "ActualFees": 0,
    "ForecastFees": 0
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 9,
    "Date": "2019-03-01",
    "ActualFees": 0,
    "ForecastFees": 0
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 10,
    "Date": "2019-04-01",
    "ActualFees": 0,
    "ForecastFees": 0
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 11,
    "Date": "2019-05-01",
    "ActualFees": 0,
    "ForecastFees": 0
  },
  {
    "OrgId": "10",
    "OrgName": "Unreal Architecture Pty Ltd",
    "FY": 2019,
    "FM": 12,
    "Date": "2019-06-01",
    "ActualFees": 0,
    "ForecastFees": 0
  }
];

export default data;

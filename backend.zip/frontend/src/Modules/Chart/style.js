export const styles = theme => ({
  root: {

  },
  slider: {
    margin: '15px 5px 15px 5px'
  }
});

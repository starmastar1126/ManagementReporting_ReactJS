export const styles = theme => ({
  root: {

  },
  tltLeft: {
    color: 'gray'
  },
  tltRight: {
    float: 'right',
    fontWeight: '600',
    color: 'black'
  }
});

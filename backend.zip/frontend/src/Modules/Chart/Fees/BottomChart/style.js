export const styles = theme => ({
  root: {

  },
  leftItem: {
    width: '30%'
  },
  rightItem: {
    width: '70%'
  }
});

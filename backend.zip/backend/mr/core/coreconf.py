# -*- coding: utf-8 -*-
"""
"""

from __future__ import division
from __future__ import absolute_import
from __future__ import print_function


class CoreConf(object):

    """Docstring for CoreConf. """

    # expire time in seconds
    AUTH_TOKEN_EXPIRE_TIME = 86400

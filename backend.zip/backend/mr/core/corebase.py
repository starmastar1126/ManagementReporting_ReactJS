# -*- coding: utf-8 -*-
"""
"""

from __future__ import division
from __future__ import absolute_import
from __future__ import print_function


class CoreBase(object):

    """Docstring for CoreBase. """

    def __init__(self, session, conf):
        """TODO: to be defined1.

        :session: TODO
        :conf: TODO

        """
        self.session = session
        self.conf = conf

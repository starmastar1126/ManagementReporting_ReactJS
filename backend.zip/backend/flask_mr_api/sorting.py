# -*- coding: utf-8 -*-
"""
"""

from __future__ import division
from __future__ import absolute_import
from __future__ import print_function


class Sorting(object):

    """Docstring for Sorting. """

    def __init__(self, field, desc=False):
        """TODO: to be defined1.

        :field: TODO
        :desc: TODO

        """
        self.field = field
        self.desc = desc
